## Real Estate Website
- Tech used: React, React Router & Chakra UI.
- You can search houses using given search filter.
- You can view full details of house by clicking on it.

### Preview

[![Real Estate Website]](https://user-images.githubusercontent.com/93486013/187375292-920f2665-af07-43b9-9b5b-d403270d6797.mp4
)
