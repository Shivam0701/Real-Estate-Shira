import HouseDetails from "../components/PropertyDetails/HouseDetails";

const PropertyDetails = () => {
  return (
    <>      
      <HouseDetails />
    </>
  )
}

export default PropertyDetails